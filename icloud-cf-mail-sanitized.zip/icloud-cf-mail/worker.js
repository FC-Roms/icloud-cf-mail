import PostalMime, { addressParser } from "postal-mime";

const DEFAULT_BLOCKED_DOMAINS = ["spam.com", "fake-mailer.com"];
const DEFAULT_SPAM_WORDS = ["casino", "crypto bonus", "buy now", "loan approved"];
const DEFAULT_MAX_MESSAGE_SIZE_BYTES = 10 * 1024 * 1024;
const DEFAULT_WORKER_ID = "icloud-cf-mail";
const DEFAULT_VIEW_TOKEN_PLACEHOLDER = "change-this-view-token";
const LOG_PAGE_SIZE = 10;
const LOGS_AUTO_REFRESH_MS = 30_000;
const MAIL_MESSAGES_TABLE = "mail_messages";
const MAIL_RECIPIENTS_TABLE = "mail_message_recipients";
const INLINE_CID_ATTACHMENT_LIMIT_BYTES = 512 * 1024;
const INLINE_CID_ATTACHMENT_TOTAL_LIMIT_BYTES = 2 * 1024 * 1024;
const QUERYABLE_MAIL_DOMAIN = "icloud.com";
const JSON_NO_STORE_HEADERS = {
  "cache-control": "no-store",
};
const PAGE_SECURITY_HEADERS = {
  "content-type": "text/html; charset=utf-8",
  "cache-control": "no-store",
  "x-content-type-options": "nosniff",
  "referrer-policy": "no-referrer",
  "content-security-policy":
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: https: http:; frame-src 'self' about:; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
};
const RECIPIENT_HEADER_NAMES = [
  "to",
  "cc",
  "bcc",
  "delivered-to",
  "x-original-to",
  "resent-to",
  "x-forwarded-to",
  "x-envelope-to",
  "envelope-to",
  "apparently-to",
  "x-apparently-to",
  "original-recipient",
  "final-recipient",
];
const EMAIL_ADDRESS_PATTERN = /[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9-]+(?:\.[a-z0-9-]+)+/gi;

const MAIL_DB_SCHEMA_STATEMENTS = [
  `CREATE TABLE IF NOT EXISTS ${MAIL_MESSAGES_TABLE} (
    id TEXT PRIMARY KEY,
    worker_id TEXT NOT NULL,
    envelope_to_email TEXT NOT NULL,
    primary_to_email TEXT NOT NULL,
    recipient_emails_json TEXT NOT NULL,
    to_header TEXT NOT NULL,
    from_email TEXT NOT NULL,
    from_name TEXT NOT NULL,
    from_header TEXT NOT NULL,
    reply_to_email TEXT NOT NULL,
    reply_to_header TEXT NOT NULL,
    subject TEXT NOT NULL,
    message_date TEXT NOT NULL,
    message_id TEXT NOT NULL,
    html_body TEXT NOT NULL,
    text_body TEXT NOT NULL,
    html_source TEXT NOT NULL,
    raw_headers_json TEXT NOT NULL,
    attachment_count INTEGER NOT NULL,
    raw_size INTEGER NOT NULL,
    parse_error TEXT NOT NULL,
    received_at TEXT NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS idx_mail_messages_worker_received
    ON ${MAIL_MESSAGES_TABLE}(worker_id, received_at DESC, id DESC)`,
  `CREATE TABLE IF NOT EXISTS ${MAIL_RECIPIENTS_TABLE} (
    worker_id TEXT NOT NULL,
    email TEXT NOT NULL,
    message_id TEXT NOT NULL,
    PRIMARY KEY (worker_id, email, message_id)
  )`,
];

const initializedMailDbs = new WeakSet();
const initializingMailDbs = new WeakMap();

function serializeScriptValue(value) {
  return JSON.stringify(value).replace(/</g, "\\u003c");
}

function normalizeHeader(value) {
  return value ? value.toString().trim() : "";
}

function normalizeEmail(value) {
  return (value || "").trim().toLowerCase();
}

function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value || "");
}

function getEmailDomain(value) {
  const email = normalizeEmail(value);
  const atIndex = email.lastIndexOf("@");

  return atIndex === -1 ? "" : email.slice(atIndex + 1);
}

function isQueryableIcloudEmail(value) {
  const email = normalizeEmail(value);

  return isValidEmail(email) && getEmailDomain(email) === QUERYABLE_MAIL_DOMAIN;
}

function addEmail(addresses, value) {
  const email = normalizeEmail(value);

  if (email && isValidEmail(email)) {
    addresses.add(email);
  }
}

function parseCsv(value, fallback = []) {
  if (!value) return fallback;

  const items = value
    .split(",")
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean);

  return items.length > 0 ? items : fallback;
}

function parsePositiveInteger(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function getErrorMessage(err) {
  return err instanceof Error ? err.message : String(err || "");
}

function getWorkerId(env) {
  return (env.WORKER_ID || DEFAULT_WORKER_ID)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]/g, "_");
}

function getWorkerUrl(env, requestUrl) {
  return (env.WORKER_URL || "").trim() || requestUrl.origin;
}

function timingSafeEqual(a, b) {
  const left = String(a || "");
  const right = String(b || "");
  const maxLength = Math.max(left.length, right.length);
  let diff = left.length ^ right.length;

  for (let index = 0; index < maxLength; index++) {
    diff |= left.charCodeAt(index % Math.max(left.length, 1)) ^
      right.charCodeAt(index % Math.max(right.length, 1));
  }

  return diff === 0;
}

function getConfiguredViewToken(env) {
  const token = normalizeHeader(env.VIEW_TOKEN);

  if (!token || token === DEFAULT_VIEW_TOKEN_PLACEHOLDER) return "";
  return token;
}

function getBearerToken(request) {
  const header = normalizeHeader(request.headers.get("authorization"));
  const match = header.match(/^Bearer\s+(.+)$/i);

  return match ? match[1].trim() : "";
}

function validateViewAccess(request, env) {
  const configuredToken = getConfiguredViewToken(env);

  if (!configuredToken) {
    return {
      ok: false,
      status: 503,
      message: "VIEW_TOKEN secret is not configured",
    };
  }

  if (!timingSafeEqual(getBearerToken(request), configuredToken)) {
    return {
      ok: false,
      status: 401,
      message: "Unauthorized",
    };
  }

  return {
    ok: true,
  };
}

function addParsedAddress(items, item) {
  if (!item) return;

  if (Array.isArray(item.group)) {
    item.group.forEach((member) => addParsedAddress(items, member));
    return;
  }

  const address = normalizeEmail(item.address);

  if (!address || !isValidEmail(address)) return;

  items.push({
    name: normalizeHeader(item.name),
    address,
  });
}

function parseAddressHeader(value) {
  const headerValue = normalizeHeader(value);
  const items = [];

  if (!headerValue) return items;

  try {
    addressParser(headerValue, { flatten: true }).forEach((item) =>
      addParsedAddress(items, item)
    );
  } catch {
    for (const match of headerValue.matchAll(EMAIL_ADDRESS_PATTERN)) {
      items.push({
        name: "",
        address: normalizeEmail(match[0]),
      });
    }
  }

  const seen = new Set();

  return items.filter((item) => {
    if (seen.has(item.address)) return false;
    seen.add(item.address);
    return true;
  });
}

function addPostalAddresses(addresses, value) {
  if (!value) return;

  const items = Array.isArray(value) ? value : [value];

  for (const item of items) {
    if (typeof item === "string") {
      parseAddressHeader(item).forEach((address) => addEmail(addresses, address.address));
      continue;
    }

    if (item && typeof item === "object") {
      if (Array.isArray(item.group)) {
        addPostalAddresses(addresses, item.group);
        continue;
      }

      addEmail(addresses, item.address);
    }
  }
}

function collectRecipientEmails(headers, envelopeTo, parsedEmail) {
  const addresses = new Set();
  addEmail(addresses, envelopeTo);

  for (const headerName of RECIPIENT_HEADER_NAMES) {
    for (const item of parseAddressHeader(headers.get(headerName))) {
      addEmail(addresses, item.address);
    }
  }

  addPostalAddresses(addresses, parsedEmail?.to);
  addPostalAddresses(addresses, parsedEmail?.cc);
  addPostalAddresses(addresses, parsedEmail?.bcc);

  return [...addresses];
}

function getPrimaryToEmail(headers, envelopeTo) {
  const toAddresses = parseAddressHeader(headers.get("to"));

  return toAddresses[0]?.address || normalizeEmail(envelopeTo);
}

function getFromDetails(headers, envelopeFrom, parsedEmail) {
  const fromHeader = normalizeHeader(headers.get("from"));
  const parsedFrom =
    (Array.isArray(parsedEmail?.from) ? parsedEmail.from[0] : parsedEmail?.from) ||
    parseAddressHeader(fromHeader)[0];
  const fromEmail = normalizeEmail(parsedFrom?.address || envelopeFrom);

  return {
    fromEmail,
    fromName: normalizeHeader(parsedFrom?.name),
    fromHeader,
  };
}

function getReplyToDetails(headers, parsedEmail) {
  const replyToHeader = normalizeHeader(headers.get("reply-to"));
  const parsedReplyTo =
    (Array.isArray(parsedEmail?.replyTo) ? parsedEmail.replyTo[0] : parsedEmail?.replyTo) ||
    parseAddressHeader(replyToHeader)[0];

  return {
    replyToEmail: normalizeEmail(parsedReplyTo?.address),
    replyToHeader,
  };
}

function getRawHeadersJson(headers) {
  const rows = [];

  for (const [name, value] of headers.entries()) {
    rows.push([name, value]);
  }

  rows.sort((a, b) => a[0].localeCompare(b[0]));
  return JSON.stringify(rows);
}

function escapeHtml(value) {
  return (value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function htmlToText(html) {
  return (html || "")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|section|article|li|h[1-6]|tr)>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/[ \t]+/g, " ")
    .replace(/\n\s+/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function textToHtml(text) {
  return `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <base target="_blank">
  <style>
    body {
      margin: 0;
      padding: 24px;
      color: #17201d;
      background: #ffffff;
      font: 15px/1.55 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      white-space: pre-wrap;
      word-break: break-word;
    }
  </style>
</head>
<body>${escapeHtml(text || "")}</body>
</html>`;
}

function stripDangerousHtml(html) {
  return (html || "")
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<object[\s\S]*?<\/object>/gi, "")
    .replace(/<embed[\s\S]*?<\/embed>/gi, "")
    .replace(/<iframe[\s\S]*?<\/iframe>/gi, "")
    .replace(/<frameset[\s\S]*?<\/frameset>/gi, "")
    .replace(/<frame[\s\S]*?>/gi, "")
    .replace(/\son\w+\s*=\s*"[^"]*"/gi, "")
    .replace(/\son\w+\s*=\s*'[^']*'/gi, "")
    .replace(/\son\w+\s*=\s*[^\s>]+/gi, "")
    .replace(/\s(href|src)\s*=\s*"javascript:[^"]*"/gi, ' $1="#"')
    .replace(/\s(href|src)\s*=\s*'javascript:[^']*'/gi, " $1='#'");
}

function ensureHtmlDocument(html, fallbackText) {
  const cleaned = stripDangerousHtml((html || "").trim());

  if (!cleaned) return textToHtml(fallbackText);
  if (/<html[\s>]/i.test(cleaned)) return cleaned;

  return `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <base target="_blank">
</head>
<body>${cleaned}</body>
</html>`;
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function normalizeContentId(value) {
  return normalizeHeader(value).replace(/^<|>$/g, "");
}

function arrayBufferToBase64(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = "";

  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }

  return btoa(binary);
}

function inlineCidAttachments(html, attachments = []) {
  let nextHtml = html || "";
  let totalBytes = 0;

  if (!nextHtml || !Array.isArray(attachments)) return nextHtml;

  for (const attachment of attachments) {
    const contentId = normalizeContentId(attachment.contentId);
    const content = attachment.content;

    if (!contentId || !content) continue;

    const bytes = content instanceof Uint8Array ? content : new Uint8Array(content);

    if (bytes.byteLength > INLINE_CID_ATTACHMENT_LIMIT_BYTES) continue;
    if (totalBytes + bytes.byteLength > INLINE_CID_ATTACHMENT_TOTAL_LIMIT_BYTES) continue;

    totalBytes += bytes.byteLength;

    const mimeType = attachment.mimeType || "application/octet-stream";
    const dataUri = `data:${mimeType};base64,${arrayBufferToBase64(bytes)}`;
    const candidates = [contentId, encodeURIComponent(contentId)];

    for (const candidate of candidates) {
      nextHtml = nextHtml.replace(
        new RegExp(`cid:${escapeRegExp(candidate)}`, "gi"),
        dataUri
      );
    }
  }

  return nextHtml;
}

async function parseIncomingMessage(message) {
  try {
    const parsedEmail = await PostalMime.parse(message.raw, {
      attachmentEncoding: "arraybuffer",
      maxNestingDepth: 50,
      maxHeadersSize: 512 * 1024,
    });
    const textBody = parsedEmail.text || htmlToText(parsedEmail.html || "");
    const htmlBody = ensureHtmlDocument(
      inlineCidAttachments(parsedEmail.html || "", parsedEmail.attachments),
      textBody
    );

    return {
      parsedEmail,
      htmlBody,
      textBody,
      htmlSource: parsedEmail.html ? "text/html" : parsedEmail.text ? "text/plain" : "none",
      attachmentCount: Array.isArray(parsedEmail.attachments)
        ? parsedEmail.attachments.length
        : 0,
      parseError: "",
    };
  } catch (err) {
    console.error("Email parse error:", err);

    return {
      parsedEmail: null,
      htmlBody: textToHtml(""),
      textBody: "",
      htmlSource: "parse-error",
      attachmentCount: 0,
      parseError: getErrorMessage(err),
    };
  }
}

async function ensureMailDbSchema(env) {
  const db = env.MAIL_DB;

  if (!db) {
    throw new Error("MAIL_DB D1 not configured");
  }

  if (initializedMailDbs.has(db)) return db;

  let initPromise = initializingMailDbs.get(db);

  if (!initPromise) {
    initPromise = (async () => {
      for (const statement of MAIL_DB_SCHEMA_STATEMENTS) {
        await db.prepare(statement).run();
      }

      initializedMailDbs.add(db);
      initializingMailDbs.delete(db);
    })().catch((err) => {
      initializingMailDbs.delete(db);
      throw err;
    });

    initializingMailDbs.set(db, initPromise);
  }

  await initPromise;
  return db;
}

function parseRecipientEmailsJson(value) {
  if (typeof value !== "string" || !value) return [];

  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed)
      ? parsed.map((item) => normalizeEmail(item)).filter((item) => isValidEmail(item))
      : [];
  } catch {
    return [];
  }
}

function mapDbMessageRow(row) {
  return {
    id: row.id,
    subject: row.subject || "",
    date: row.date || "",
    htmlBody: row.htmlBody || "",
    receivedAt: row.receivedAt || "",
  };
}

function parseRawHeadersJson(value) {
  if (typeof value !== "string" || !value) return [];

  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function saveMailMessage(env, messageData) {
  const db = await ensureMailDbSchema(env);
  const id = crypto.randomUUID();
  const workerId = getWorkerId(env);
  const receivedAt = new Date().toISOString();
  const recipientEmails = [...new Set((messageData.recipientEmails || []).map(normalizeEmail))]
    .filter((email) => isQueryableIcloudEmail(email));
  const primaryToEmail = isQueryableIcloudEmail(messageData.primaryToEmail)
    ? normalizeEmail(messageData.primaryToEmail)
    : recipientEmails[0] || "";

  await db
    .prepare(
      `INSERT INTO ${MAIL_MESSAGES_TABLE} (
        id, worker_id, envelope_to_email, primary_to_email, recipient_emails_json,
        to_header, from_email, from_name, from_header, reply_to_email,
        reply_to_header, subject, message_date, message_id, html_body,
        text_body, html_source, raw_headers_json, attachment_count,
        raw_size, parse_error, received_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .bind(
      id,
      workerId,
      normalizeEmail(messageData.envelopeToEmail),
      primaryToEmail,
      JSON.stringify(recipientEmails),
      normalizeHeader(messageData.toHeader),
      normalizeEmail(messageData.fromEmail),
      normalizeHeader(messageData.fromName),
      normalizeHeader(messageData.fromHeader),
      normalizeEmail(messageData.replyToEmail),
      normalizeHeader(messageData.replyToHeader),
      normalizeHeader(messageData.subject),
      normalizeHeader(messageData.date),
      normalizeHeader(messageData.messageId),
      messageData.htmlBody || "",
      messageData.textBody || "",
      normalizeHeader(messageData.htmlSource) || "none",
      messageData.rawHeadersJson || "[]",
      Number(messageData.attachmentCount) || 0,
      Number(messageData.rawSize) || 0,
      normalizeHeader(messageData.parseError),
      receivedAt
    )
    .run();

  for (const recipient of recipientEmails) {
    await db
      .prepare(
        `INSERT OR IGNORE INTO ${MAIL_RECIPIENTS_TABLE}
        (worker_id, email, message_id)
        VALUES (?, ?, ?)`
      )
      .bind(workerId, recipient, id)
      .run();
  }

  return id;
}

function encodeBase64Url(value) {
  const bytes = new TextEncoder().encode(value);
  let binary = "";

  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }

  return btoa(binary)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function decodeBase64Url(value) {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = base64.padEnd(Math.ceil(base64.length / 4) * 4, "=");
  const binary = atob(padded);
  const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));

  return new TextDecoder().decode(bytes);
}

function encodeCursor(cursor) {
  if (!cursor) return null;

  return encodeBase64Url(JSON.stringify({ v: 1, c: cursor }));
}

function decodeCursor(value) {
  const token = (value || "").trim();

  if (!token) return { ok: true, cursor: undefined };

  try {
    const data = JSON.parse(decodeBase64Url(token));

    if (data?.v !== 1 || typeof data.c !== "string" || !data.c) {
      return { ok: false };
    }

    return {
      ok: true,
      cursor: data.c,
    };
  } catch {
    return { ok: false };
  }
}

function encodeLogCursorFromRow(row) {
  if (!row?.receivedAt || !row?.id) return null;

  return encodeCursor(
    JSON.stringify({
      receivedAt: row.receivedAt,
      id: row.id,
    })
  );
}

function decodeLogCursor(value) {
  const decoded = decodeCursor(value);

  if (!decoded.ok) return { ok: false };
  if (!decoded.cursor) return { ok: true, cursor: null };

  try {
    const data = JSON.parse(decoded.cursor);

    if (
      typeof data?.receivedAt !== "string" ||
      !data.receivedAt ||
      typeof data?.id !== "string" ||
      !data.id
    ) {
      return { ok: false };
    }

    return {
      ok: true,
      cursor: {
        receivedAt: data.receivedAt,
        id: data.id,
      },
    };
  } catch {
    return { ok: false };
  }
}

function getSearchParamPreservePlus(url, name) {
  const query = url.search.startsWith("?") ? url.search.slice(1) : url.search;

  for (const part of query.split("&")) {
    if (!part) continue;

    const separatorIndex = part.indexOf("=");
    const rawName = separatorIndex === -1 ? part : part.slice(0, separatorIndex);
    const rawValue = separatorIndex === -1 ? "" : part.slice(separatorIndex + 1);

    try {
      if (decodeURIComponent(rawName.replace(/\+/g, " ")) !== name) continue;

      return decodeURIComponent(rawValue.replace(/\+/g, "%2B"));
    } catch {
      return "";
    }
  }

  return "";
}

async function listMailMessages(env, { email, cursor } = {}) {
  const db = await ensureMailDbSchema(env);
  const workerId = getWorkerId(env);
  const emailFilter = normalizeEmail(email);
  const conditions = ["m.worker_id = ?"];
  const params = [workerId];

  if (emailFilter) {
    conditions.push(
      `EXISTS (
        SELECT 1
        FROM ${MAIL_RECIPIENTS_TABLE} r
        WHERE r.worker_id = m.worker_id
          AND r.message_id = m.id
          AND r.email = ?
      )`
    );
    params.push(emailFilter);
  }

  if (cursor) {
    conditions.push("(m.received_at < ? OR (m.received_at = ? AND m.id < ?))");
    params.push(cursor.receivedAt, cursor.receivedAt, cursor.id);
  }

  params.push(LOG_PAGE_SIZE + 1);

  const result = await db
    .prepare(
      `SELECT
        m.id,
        m.subject,
        m.message_date AS "date",
        m.html_body AS htmlBody,
        m.received_at AS receivedAt
      FROM ${MAIL_MESSAGES_TABLE} m
      WHERE ${conditions.join(" AND ")}
      ORDER BY m.received_at DESC, m.id DESC
      LIMIT ?`
    )
    .bind(...params)
    .all();

  const rows = Array.isArray(result?.results) ? result.results : [];
  const mapped = rows.map(mapDbMessageRow);
  const hasMore = mapped.length > LOG_PAGE_SIZE;
  const messages = hasMore ? mapped.slice(0, LOG_PAGE_SIZE) : mapped;
  const nextCursor = hasMore
    ? encodeLogCursorFromRow(messages[messages.length - 1])
    : null;

  return {
    messages,
    logs: messages,
    pagination: {
      limit: LOG_PAGE_SIZE,
      hasMore: Boolean(nextCursor),
      nextCursor,
    },
  };
}

function renderMailPage(workerUrl) {
  const serializedWorkerUrl = serializeScriptValue(workerUrl);

  return `<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>iCloud Mail</title>
  <style>
    :root {
      color-scheme: light;
      --bg: #f7f8f5;
      --panel: #ffffff;
      --panel-soft: #f0f5f7;
      --ink: #17201d;
      --muted: #66716d;
      --line: #dce5e1;
      --accent: #176b7a;
      --accent-strong: #0f5260;
      --warn: #9d4d12;
      --danger: #b42318;
      --focus: rgba(23, 107, 122, 0.18);
      --shadow: 0 16px 40px rgba(23, 32, 29, 0.1);
    }

    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      min-height: 100vh;
      background: var(--bg);
      color: var(--ink);
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      letter-spacing: 0;
    }

    button,
    input {
      font: inherit;
    }

    button {
      min-height: 42px;
      border: 0;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 750;
    }

    button:disabled {
      cursor: not-allowed;
      opacity: 0.55;
    }

    .page {
      width: min(1180px, calc(100% - 32px));
      margin: 0 auto;
      padding: 28px 0 48px;
    }

    .topbar {
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      gap: 18px;
      margin-bottom: 18px;
    }

    h1 {
      margin: 0;
      font-size: clamp(1.8rem, 4vw, 3rem);
      line-height: 1;
      letter-spacing: 0;
    }

    .status {
      border: 1px solid var(--line);
      border-radius: 999px;
      background: var(--panel);
      color: var(--accent-strong);
      padding: 8px 12px;
      font-size: 0.86rem;
      font-weight: 800;
      white-space: nowrap;
    }

    .search-panel {
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--panel);
      box-shadow: var(--shadow);
      padding: 16px;
    }

    .search-form {
      display: grid;
      grid-template-columns: minmax(210px, 1fr) minmax(160px, 0.55fr) auto auto;
      gap: 10px;
      align-items: end;
    }

    label {
      display: grid;
      gap: 7px;
      color: var(--muted);
      font-size: 0.8rem;
      font-weight: 800;
      text-transform: uppercase;
    }

    input {
      width: 100%;
      min-height: 42px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: #fff;
      color: var(--ink);
      outline: none;
      padding: 0 12px;
    }

    input:focus {
      border-color: var(--accent);
      box-shadow: 0 0 0 4px var(--focus);
    }

    .primary {
      background: var(--accent);
      color: #fff;
      padding: 0 16px;
    }

    .primary:hover {
      background: var(--accent-strong);
    }

    .secondary {
      border: 1px solid var(--line);
      background: #fff;
      color: var(--ink);
      padding: 0 14px;
    }

    .meta-line {
      display: flex;
      flex-wrap: wrap;
      gap: 10px 16px;
      margin-top: 12px;
      color: var(--muted);
      font-size: 0.9rem;
    }

    .message {
      margin-top: 12px;
      border-radius: 8px;
      background: var(--panel-soft);
      color: var(--muted);
      padding: 11px 12px;
      line-height: 1.45;
    }

    .message.error {
      background: #fff1f0;
      color: var(--danger);
    }

    .messages {
      display: grid;
      gap: 14px;
      margin-top: 16px;
    }

    .mail-card {
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--panel);
      box-shadow: 0 10px 24px rgba(23, 32, 29, 0.07);
      overflow: hidden;
    }

    .mail-head {
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 12px;
      padding: 16px;
      border-bottom: 1px solid var(--line);
    }

    .mail-head h2 {
      margin: 0;
      font-size: 1.05rem;
      line-height: 1.35;
      letter-spacing: 0;
    }

    .mail-date {
      color: var(--muted);
      font-size: 0.86rem;
      font-weight: 800;
      white-space: nowrap;
    }

    .mail-frame {
      width: 100%;
      height: min(680px, 78vh);
      border: 0;
      display: block;
      background: #fff;
    }

    .load-more {
      display: flex;
      justify-content: center;
      margin-top: 18px;
    }

    .hidden {
      display: none;
    }

    @media (max-width: 760px) {
      .page {
        width: min(100% - 20px, 1180px);
        padding-top: 18px;
      }

      .topbar,
      .mail-head {
        align-items: flex-start;
        grid-template-columns: 1fr;
      }

      .topbar {
        display: grid;
      }

      .search-form {
        grid-template-columns: 1fr;
      }

      .mail-date {
        white-space: normal;
      }
    }
  </style>
</head>
<body>
  <main class="page">
    <section class="topbar" aria-labelledby="page-title">
      <h1 id="page-title">iCloud Mail</h1>
      <div class="status" data-auto-status>Auto refresh: off</div>
    </section>

    <section class="search-panel">
      <form class="search-form" data-mail-form>
        <label>
          Email iCloud
          <input data-mail-input type="email" name="email" placeholder="farrago.mull-1u@icloud.com" autocomplete="email" pattern="^[^\\s@]+@icloud\\.com$" title="Chỉ nhập email @icloud.com" required>
        </label>
        <label>
          Mã truy cập
          <input data-token-input type="password" name="token" placeholder="VIEW_TOKEN" autocomplete="current-password" required>
        </label>
        <button class="primary" type="submit" data-search-button>Tìm</button>
        <button class="secondary" type="button" data-refresh-button>Refresh</button>
      </form>
      <div class="meta-line">
        <span data-current-mail>Chưa chọn email</span>
        <span data-last-updated>Chưa cập nhật</span>
      </div>
      <div class="message" data-message>Nhập địa chỉ iCloud để xem mail.</div>
    </section>

    <section class="messages" data-messages aria-live="polite"></section>
    <div class="load-more">
      <button class="secondary hidden" type="button" data-load-more>Tải thêm</button>
    </div>
  </main>

  <script>
    const WORKER_URL = ${serializedWorkerUrl};
    const LOGS_URL = new URL("/logs", WORKER_URL.endsWith("/") ? WORKER_URL : WORKER_URL + "/").toString();
    const AUTO_REFRESH_MS = ${LOGS_AUTO_REFRESH_MS};
    const AUTO_REFRESH_SECONDS = Math.round(AUTO_REFRESH_MS / 1000);

    const form = document.querySelector("[data-mail-form]");
    const input = document.querySelector("[data-mail-input]");
    const tokenInput = document.querySelector("[data-token-input]");
    const searchButton = document.querySelector("[data-search-button]");
    const refreshButton = document.querySelector("[data-refresh-button]");
    const loadMoreButton = document.querySelector("[data-load-more]");
    const messagesEl = document.querySelector("[data-messages]");
    const messageEl = document.querySelector("[data-message]");
    const currentMailEl = document.querySelector("[data-current-mail]");
    const lastUpdatedEl = document.querySelector("[data-last-updated]");
    const autoStatusEl = document.querySelector("[data-auto-status]");

    let currentMail = "";
    let accessToken = window.sessionStorage.getItem("icloud-mail-view-token") || "";
    let nextCursor = null;
    let loading = false;
    let autoRefreshId = null;
    let requestId = 0;

    tokenInput.value = accessToken;

    function setLoading(value) {
      loading = value;
      searchButton.disabled = value;
      refreshButton.disabled = value;
      loadMoreButton.disabled = value;
    }

    function setMessage(text, type = "info") {
      messageEl.textContent = text;
      messageEl.classList.toggle("error", type === "error");
    }

    function setAutoRefresh(active) {
      if (autoRefreshId) {
        window.clearInterval(autoRefreshId);
        autoRefreshId = null;
      }

      if (!active) {
        autoStatusEl.textContent = "Auto refresh: off";
        return;
      }

      autoStatusEl.textContent = "Auto refresh: " + AUTO_REFRESH_SECONDS + "s";
      autoRefreshId = window.setInterval(() => {
        if (!currentMail || loading) return;
        fetchMessages({ append: false, cursor: null, silent: true });
      }, AUTO_REFRESH_MS);
    }

    function formatDate(value) {
      if (!value) return "Không rõ";
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return value;

      return new Intl.DateTimeFormat("vi-VN", {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(date);
    }

    function isIcloudEmail(value) {
      return /^[^\\s@]+@icloud\\.com$/i.test((value || "").trim());
    }

    function createMessageCard(item) {
      const card = document.createElement("article");
      card.className = "mail-card";

      const head = document.createElement("header");
      head.className = "mail-head";
      const title = document.createElement("h2");
      title.textContent = item.subject || "(Không có tiêu đề)";
      const date = document.createElement("div");
      date.className = "mail-date";
      date.textContent = formatDate(item.date || item.receivedAt);
      head.append(title, date);

      const iframe = document.createElement("iframe");
      iframe.className = "mail-frame";
      iframe.setAttribute("sandbox", "allow-popups");
      iframe.setAttribute("referrerpolicy", "no-referrer");
      iframe.srcdoc = item.htmlBody || "";

      card.append(head, iframe);
      return card;
    }

    function renderMessages(items, append) {
      if (!append) messagesEl.textContent = "";

      if (!append && items.length === 0) {
        setMessage("Chưa có mail cho email này.");
        return;
      }

      const fragment = document.createDocumentFragment();
      items.forEach((item) => fragment.append(createMessageCard(item)));
      messagesEl.append(fragment);
      setMessage(append ? "Đã tải thêm mail." : "Đã cập nhật danh sách mail.");
    }

    async function fetchMessages({ append = false, cursor = null, silent = false } = {}) {
      if (!currentMail) {
        setMessage("Nhập email trước khi refresh.", "error");
        input.focus();
        return;
      }

      if (!isIcloudEmail(currentMail)) {
        setMessage("Chỉ được tra cứu email @icloud.com.", "error");
        input.focus();
        return;
      }

      accessToken = tokenInput.value.trim();
      if (!accessToken) {
        setMessage("Nhập mã truy cập trước khi tải mail.", "error");
        tokenInput.focus();
        return;
      }

      window.sessionStorage.setItem("icloud-mail-view-token", accessToken);

      const currentRequest = ++requestId;
      const params = new URLSearchParams({ mail: currentMail });
      if (cursor) params.set("cursor", cursor);

      setLoading(true);
      if (!silent) setMessage(append ? "Đang tải thêm..." : "Đang tải mail...");

      try {
        const response = await fetch(LOGS_URL + "?" + params.toString(), {
          cache: "no-store",
          headers: {
            authorization: "Bearer " + accessToken,
          },
        });

        if (!response.ok) {
          const text = await response.text();
          throw new Error(text || "Không thể tải mail");
        }

        const data = await response.json();
        const items = Array.isArray(data.messages) ? data.messages : data.logs;

        if (!Array.isArray(items)) throw new Error("Response không hợp lệ");
        if (currentRequest !== requestId) return;

        nextCursor = data.pagination?.nextCursor || null;
        renderMessages(items, append);
        currentMailEl.textContent = currentMail;
        lastUpdatedEl.textContent = "Cập nhật: " + formatDate(new Date().toISOString());
        loadMoreButton.classList.toggle("hidden", !nextCursor);
      } catch (err) {
        if (currentRequest !== requestId) return;
        setMessage(err instanceof Error ? err.message : "Không thể tải mail", "error");
      } finally {
        if (currentRequest === requestId) setLoading(false);
      }
    }

    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const email = input.value.trim().toLowerCase();
      accessToken = tokenInput.value.trim();
      if (!email) return;
      if (!isIcloudEmail(email)) {
        setMessage("Chỉ được tra cứu email @icloud.com.", "error");
        input.focus();
        return;
      }
      if (!accessToken) {
        setMessage("Nhập mã truy cập trước khi tìm mail.", "error");
        tokenInput.focus();
        return;
      }

      currentMail = email;
      nextCursor = null;
      setAutoRefresh(true);
      fetchMessages({ append: false });
    });

    refreshButton.addEventListener("click", () => {
      const email = input.value.trim().toLowerCase();
      accessToken = tokenInput.value.trim();
      if (email) {
        if (!isIcloudEmail(email)) {
          setMessage("Chỉ được tra cứu email @icloud.com.", "error");
          input.focus();
          return;
        }

        currentMail = email;
      }
      if (!accessToken) {
        setMessage("Nhập mã truy cập trước khi refresh.", "error");
        tokenInput.focus();
        return;
      }
      nextCursor = null;
      setAutoRefresh(Boolean(currentMail));
      fetchMessages({ append: false });
    });

    loadMoreButton.addEventListener("click", () => {
      if (!nextCursor) return;
      fetchMessages({ append: true, cursor: nextCursor });
    });
  </script>
</body>
</html>`;
}

async function handleEmail(message, env) {
  const adminEmail = normalizeEmail(env.ADMIN_EMAIL);
  const blockedDomains = parseCsv(env.BLOCKED_DOMAINS, DEFAULT_BLOCKED_DOMAINS);
  const spamWords = parseCsv(env.SPAM_WORDS, DEFAULT_SPAM_WORDS);
  const maxMessageSize = parsePositiveInteger(
    env.MAX_MESSAGE_SIZE_BYTES,
    DEFAULT_MAX_MESSAGE_SIZE_BYTES
  );

  if (!adminEmail) {
    message.setReject("ADMIN_EMAIL not configured");
    return;
  }

  const envelopeToEmail = normalizeEmail(message.to);
  const envelopeFromEmail = normalizeEmail(message.from);
  const subject = normalizeHeader(message.headers.get("subject"));

  if (message.rawSize > maxMessageSize) {
    message.setReject("Message too large");
    return;
  }

  const senderDomain = envelopeFromEmail.split("@")[1] || "";

  if (blockedDomains.includes(senderDomain)) {
    message.setReject("Sender blocked");
    return;
  }

  const lowerSubject = subject.toLowerCase();

  if (spamWords.some((word) => lowerSubject.includes(word))) {
    message.setReject("Spam detected");
    return;
  }

  const parsed = await parseIncomingMessage(message);
  const fromDetails = getFromDetails(message.headers, envelopeFromEmail, parsed.parsedEmail);
  const replyToDetails = getReplyToDetails(message.headers, parsed.parsedEmail);
  const detectedRecipientEmails = collectRecipientEmails(
    message.headers,
    envelopeToEmail,
    parsed.parsedEmail
  );
  const recipientEmails = detectedRecipientEmails.filter(isQueryableIcloudEmail);
  const primaryToEmail =
    recipientEmails[0] ||
    (isQueryableIcloudEmail(getPrimaryToEmail(message.headers, envelopeToEmail))
      ? getPrimaryToEmail(message.headers, envelopeToEmail)
      : "");

  await saveMailMessage(env, {
    envelopeToEmail,
    primaryToEmail,
    recipientEmails,
    toHeader: normalizeHeader(message.headers.get("to")),
    ...fromDetails,
    ...replyToDetails,
    subject,
    date: normalizeHeader(message.headers.get("date")),
    messageId: normalizeHeader(message.headers.get("message-id")),
    htmlBody: parsed.htmlBody,
    textBody: parsed.textBody,
    htmlSource: parsed.htmlSource,
    rawHeadersJson: getRawHeadersJson(message.headers),
    attachmentCount: parsed.attachmentCount,
    rawSize: message.rawSize,
    parseError: parsed.parseError,
  });

  const headers = new Headers();
  headers.set("X-Original-To", envelopeToEmail);
  if (primaryToEmail) {
    headers.set("X-Indexed-Recipient", primaryToEmail);
  }
  headers.set("X-Processed-By", "icloud-cf-mail-worker");

  await message.forward(adminEmail, headers);
}

export default {
  async email(message, env, ctx) {
    try {
      await handleEmail(message, env, ctx);
    } catch (err) {
      console.error("Email worker error:", err);

      try {
        if (env.ADMIN_EMAIL) {
          await message.forward(env.ADMIN_EMAIL);
          return;
        }
      } catch (forwardErr) {
        console.error("Fallback forward failed:", forwardErr);
      }

      message.setReject("Internal error");
    }
  },

  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/mail")) {
      return new Response(renderMailPage(getWorkerUrl(env, url)), {
        headers: PAGE_SECURITY_HEADERS,
      });
    }

    if (request.method === "GET" && url.pathname === "/health") {
      return Response.json({
        ok: true,
        service: "icloud-cf-mail",
        workerId: getWorkerId(env),
      });
    }

    if (url.pathname === "/logs" || url.pathname === "/messages") {
      const mail = normalizeEmail(getSearchParamPreservePlus(url, "mail"));

      if (request.method === "OPTIONS") {
        return new Response(null, {
          status: 204,
          headers: JSON_NO_STORE_HEADERS,
        });
      }

      if (request.method !== "GET") {
        return new Response("Method not allowed", {
          status: 405,
          headers: JSON_NO_STORE_HEADERS,
        });
      }

      if (!mail) {
        return new Response("mail @icloud.com is required", {
          status: 400,
          headers: JSON_NO_STORE_HEADERS,
        });
      }

      if (!isQueryableIcloudEmail(mail)) {
        return new Response("Only @icloud.com email can be queried", {
          status: 400,
          headers: JSON_NO_STORE_HEADERS,
        });
      }

      const access = validateViewAccess(request, env);

      if (!access.ok) {
        return new Response(access.message, {
          status: access.status,
          headers: JSON_NO_STORE_HEADERS,
        });
      }

      const cursor = decodeLogCursor(url.searchParams.get("cursor"));

      if (!cursor.ok) {
        return new Response("Invalid cursor", {
          status: 400,
          headers: JSON_NO_STORE_HEADERS,
        });
      }

      try {
        const payload = await listMailMessages(env, {
          email: mail,
          cursor: cursor.cursor,
        });

        return Response.json(payload, {
          headers: JSON_NO_STORE_HEADERS,
        });
      } catch (err) {
        console.error("Read messages failed:", err);

        return Response.json(
          {
            error: "Failed to read messages",
            detail: getErrorMessage(err),
          },
          {
            status: 500,
            headers: JSON_NO_STORE_HEADERS,
          }
        );
      }
    }

    return new Response("Not found", { status: 404 });
  },
};
